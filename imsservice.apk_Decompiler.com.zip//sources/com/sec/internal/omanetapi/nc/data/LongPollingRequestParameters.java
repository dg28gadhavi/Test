package com.sec.internal.omanetapi.nc.data;

public class LongPollingRequestParameters {
}
