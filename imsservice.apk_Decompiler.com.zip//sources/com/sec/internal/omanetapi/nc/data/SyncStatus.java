package com.sec.internal.omanetapi.nc.data;

public class SyncStatus {
    public String status;

    public String toString() {
        return "SyncStatus {  status: " + this.status + " }";
    }
}
