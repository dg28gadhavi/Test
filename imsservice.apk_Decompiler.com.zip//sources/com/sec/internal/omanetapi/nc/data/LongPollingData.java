package com.sec.internal.omanetapi.nc.data;

import java.net.URL;

public class LongPollingData extends ChannelData {
    public URL channelURL;
    public Integer maxNotifications;
}
