package com.sec.internal.omanetapi.nc.data;

public class GcmChannelData extends ChannelData {
    public String channelSubType;
    public String channelSubTypeVersion;
    public Integer maxNotifications;
    public String registrationToken;
}
