package com.sec.internal.omanetapi.nc.data;

public class NotificationChannelLifetime {
    public long channelLifetime;
}
