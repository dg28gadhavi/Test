package com.sec.internal.omanetapi.nc.data;

public class SyncConfig {
    public String configType;

    public String toString() {
        return "SyncConfig { configType: " + this.configType + " }";
    }
}
