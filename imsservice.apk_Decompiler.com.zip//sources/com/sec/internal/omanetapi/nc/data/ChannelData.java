package com.sec.internal.omanetapi.nc.data;

public class ChannelData {
}
