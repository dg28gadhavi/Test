package com.sec.internal.omanetapi.nc.data;

public class SyncContact {
    public String syncType;

    public String toString() {
        return "SyncContact { syncType: " + this.syncType + " }";
    }
}
