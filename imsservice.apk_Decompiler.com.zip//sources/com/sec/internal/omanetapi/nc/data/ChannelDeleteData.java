package com.sec.internal.omanetapi.nc.data;

public class ChannelDeleteData {
    public String channelUrl;
    public String deleteReason;
    public boolean isNeedRecreateChannel;
}
