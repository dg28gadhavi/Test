package com.sec.internal.omanetapi.nc.data;

public class SyncBlockfilter {
    public String syncType;

    public String toString() {
        return "SyncBlockfilter { syncType: " + this.syncType + " }";
    }
}
