package com.sec.internal.omanetapi.nc.data;

import com.sec.internal.omanetapi.nms.data.LargePollingNotification;
import com.sec.internal.omanetapi.nms.data.NmsEventList;

public class NotificationList {
    public LargePollingNotification largePollingNotification;
    public NmsEventList nmsEventList;
}
