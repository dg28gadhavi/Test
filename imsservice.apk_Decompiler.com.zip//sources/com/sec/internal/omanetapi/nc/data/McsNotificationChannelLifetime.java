package com.sec.internal.omanetapi.nc.data;

public class McsNotificationChannelLifetime {
    public int channelLifetime;

    public String toString() {
        return "notificationChannelLifetime{ channelLifetime: " + this.channelLifetime + " }";
    }
}
