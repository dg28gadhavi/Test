package com.sec.internal.omanetapi.nc.data;

import java.net.URL;

public class NotificationChannelList {
    public NotificationChannel notificationChannel;
    public URL resourceURL;
}
