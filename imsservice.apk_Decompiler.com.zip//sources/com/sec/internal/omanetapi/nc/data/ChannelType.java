package com.sec.internal.omanetapi.nc.data;

public enum ChannelType {
    LongPolling,
    NativeChannel
}
