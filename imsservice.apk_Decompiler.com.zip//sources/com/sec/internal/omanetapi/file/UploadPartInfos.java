package com.sec.internal.omanetapi.file;

import com.google.gson.annotations.SerializedName;

public class UploadPartInfos {
    @SerializedName("uploadedPartInfos")
    public UploadPartInfo[] uploadPartInfoArray;
}
