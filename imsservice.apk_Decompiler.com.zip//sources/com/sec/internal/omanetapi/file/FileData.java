package com.sec.internal.omanetapi.file;

public class FileData {
    public String contentDisposition;
    public String contentType;
    public String fileName;
    public String filePath;
}
