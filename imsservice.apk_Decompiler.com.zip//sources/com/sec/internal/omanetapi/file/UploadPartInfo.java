package com.sec.internal.omanetapi.file;

public class UploadPartInfo {
    public int partNum;
    public String partTag;
}
