package com.sec.internal.omanetapi.nms.data;

import java.net.URL;

public class Reference {
    public String path;
    public URL resourceURL;
}
