package com.sec.internal.omanetapi.nms.data;

public class PathList {
    public String[] path;
}
