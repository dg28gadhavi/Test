package com.sec.internal.omanetapi.nms.data;

public class ReferenceList {
    public FolderReferenceList folders;
    public ObjectReferenceList objects;
}
