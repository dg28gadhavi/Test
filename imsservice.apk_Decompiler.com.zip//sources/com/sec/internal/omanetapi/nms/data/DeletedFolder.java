package com.sec.internal.omanetapi.nms.data;

import java.net.URL;

public class DeletedFolder {
    public long lastModSeq;
    public URL resourceURL;
}
