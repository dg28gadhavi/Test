package com.sec.internal.omanetapi.nms.data;

public class LargePollingNotification {
    public String channelExpiry;
    public String channelURL;
}
