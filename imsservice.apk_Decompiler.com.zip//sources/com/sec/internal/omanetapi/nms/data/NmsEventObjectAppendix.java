package com.sec.internal.omanetapi.nms.data;

public class NmsEventObjectAppendix {
    public Attribute[] attribute;
}
