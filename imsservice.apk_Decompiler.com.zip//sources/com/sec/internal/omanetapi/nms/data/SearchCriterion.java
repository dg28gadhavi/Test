package com.sec.internal.omanetapi.nms.data;

public class SearchCriterion {
    public String name;
    public String type;
    public String value;
}
