package com.sec.internal.omanetapi.nms.data;

import java.net.URL;

public class NmsSubscriptionList {
    public URL resourceURL;
    public NmsSubscription[] subscription;
}
