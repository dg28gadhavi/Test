package com.sec.internal.omanetapi.nms.data;

public class ObjectList {
    public String creationCursor;
    public String cursor;
    public Object[] object;
}
