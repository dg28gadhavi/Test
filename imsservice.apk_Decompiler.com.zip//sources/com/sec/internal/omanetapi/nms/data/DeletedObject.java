package com.sec.internal.omanetapi.nms.data;

import java.net.URL;

public class DeletedObject {
    public String correlationId;
    public String correlationTag;
    public long lastModSeq;
    public URL resourceURL;
}
