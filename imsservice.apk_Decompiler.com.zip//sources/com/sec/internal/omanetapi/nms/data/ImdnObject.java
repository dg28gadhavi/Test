package com.sec.internal.omanetapi.nms.data;

public class ImdnObject {
    public ImdnInfo[] imdnInfo;
    public String originalTo;
}
