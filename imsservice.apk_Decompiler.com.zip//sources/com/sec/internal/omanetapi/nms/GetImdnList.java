package com.sec.internal.omanetapi.nms;

import com.sec.internal.omanetapi.nms.data.ImdnList;

public class GetImdnList {
    public ImdnList imdnList;
}
