package com.sec.internal.omanetapi.nms.data;

public class BulkDelete {
    public ObjectReferenceList objects;
    public SelectionCriteria selectionCriteria;
}
