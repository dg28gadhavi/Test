package com.sec.internal.omanetapi.nms.data;

public class TargetSourceRef {
    public ReferenceList sourceRefs;
    public Reference targetRef;
}
