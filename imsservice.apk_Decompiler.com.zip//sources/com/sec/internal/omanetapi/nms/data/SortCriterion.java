package com.sec.internal.omanetapi.nms.data;

public class SortCriterion {
    public String name;
    public String order;
    public String type;
}
