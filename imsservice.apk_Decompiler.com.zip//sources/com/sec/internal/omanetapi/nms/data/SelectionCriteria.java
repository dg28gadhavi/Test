package com.sec.internal.omanetapi.nms.data;

public class SelectionCriteria {
    public String fromCursor;
    public int maxEntries;
    public Boolean nonRecursiveScope;
    public SearchCriteria searchCriteria;
    public Reference searchScope;
    public SortCriteria sortCriteria;
}
