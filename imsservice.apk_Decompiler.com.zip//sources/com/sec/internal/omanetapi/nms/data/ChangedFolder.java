package com.sec.internal.omanetapi.nms.data;

import java.net.URL;

class ChangedFolder {
    public long lastModSeq;
    public String name;
    public URL parentFolder;
    public URL resourceURL;

    ChangedFolder() {
    }
}
