package com.sec.internal.omanetapi.nms.data;

public class SearchCriteria {
    public SearchCriterion[] criterion;
    public String operator;
}
