package com.sec.internal.omanetapi.nms.data;

import java.net.URL;

public class Object {
    public AttributeList attributes;
    public String correlationId;
    public String correlationTag;
    public FlagList flags;
    public ImdnList imdns;
    public String importance;
    public Long lastModSeq;
    public URL parentFolder;
    public String parentFolderPath;
    public String path;
    public PayloadPartInfo[] payloadPart;
    public URL payloadURL;
    public String protocol;
    public URL resourceURL;
    public String sensitivity;
}
