package com.sec.internal.omanetapi.nms.data;

public class AttributeList {
    public Attribute[] attribute;
}
