package com.sec.internal.omanetapi.nms.data;

public class Attribute {
    public String name;
    public String[] value;
}
