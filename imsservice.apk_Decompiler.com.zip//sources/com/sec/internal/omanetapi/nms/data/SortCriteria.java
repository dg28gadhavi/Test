package com.sec.internal.omanetapi.nms.data;

public class SortCriteria {
    public SortCriterion[] criterion;
}
