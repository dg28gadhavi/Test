package com.sec.internal.omanetapi.nms.data;

public class NmsSubscriptionUpdate {
    public int duration;
    public String restartToken;
}
