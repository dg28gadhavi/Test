package com.sec.internal.omanetapi.nms.data;

public class BulkResponseList {
    public Response[] response;
}
