package com.sec.internal.omanetapi.nms.data;

public class FolderReferenceList {
    public Reference[] folderReference;
}
