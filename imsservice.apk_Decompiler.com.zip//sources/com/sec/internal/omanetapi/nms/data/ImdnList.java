package com.sec.internal.omanetapi.nms.data;

public class ImdnList {
    public ImdnObject[] imdn;
    public long lastModSeq;
    public String resourceURL;
}
