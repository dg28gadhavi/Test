package com.sec.internal.omanetapi.nms.data;

public class FolderList {
    public String cursor;
    public Folder[] folder;
}
