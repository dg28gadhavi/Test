package com.sec.internal.omanetapi.nms.data;

public class ImdnInfo {
    public String date;
    public String type;
}
