package com.sec.internal.omanetapi.common.data;

public class CallbackReference {
    public String callbackData;
    public NotificationFormat notificationFormat;
    public String notifyURL;
}
