package com.sec.internal.omanetapi.common.data;

import java.net.URL;

public class FileUploadResponse {
    public String contentType;
    public String fileName;
    public URL href;
    public int size;
}
