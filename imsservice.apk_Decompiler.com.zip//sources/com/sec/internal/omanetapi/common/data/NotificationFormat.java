package com.sec.internal.omanetapi.common.data;

public enum NotificationFormat {
    XML,
    JSON
}
