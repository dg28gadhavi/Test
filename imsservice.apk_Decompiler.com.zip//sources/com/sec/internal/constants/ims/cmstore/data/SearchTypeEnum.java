package com.sec.internal.constants.ims.cmstore.data;

public enum SearchTypeEnum {
    Date,
    Attribute,
    AllTextAttributes,
    Flag,
    WholeWord,
    VanishedObjects,
    CreatedObjects,
    PresetSearch
}
