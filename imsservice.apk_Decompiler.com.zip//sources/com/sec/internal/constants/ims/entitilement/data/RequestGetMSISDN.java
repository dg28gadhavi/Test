package com.sec.internal.constants.ims.entitilement.data;

public class RequestGetMSISDN extends NSDSRequest {
}
