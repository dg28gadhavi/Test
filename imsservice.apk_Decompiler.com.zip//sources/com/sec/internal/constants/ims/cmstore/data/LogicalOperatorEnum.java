package com.sec.internal.constants.ims.cmstore.data;

public class LogicalOperatorEnum {
    public static final String And = "And";
    public static final String Not = "Not";
    public static final String Or = "Or";
}
