package com.sec.internal.constants.ims.config;

import com.google.gson.JsonElement;
import java.util.function.Function;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class StringArrayCarrierConfig$$ExternalSyntheticLambda0 implements Function {
    public final Object apply(Object obj) {
        return ((JsonElement) obj).getAsString();
    }
}
