package com.sec.internal.constants.ims.entitilement.data;

import com.google.gson.annotations.SerializedName;

public class RequestManageLocationAndTC extends NSDSRequest {
    @SerializedName("service-fingerprint")
    public String serviceFingerprint;
}
