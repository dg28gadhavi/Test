package com.sec.internal.constants.ims;

import java.util.Set;
import java.util.function.Predicate;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda28 implements Predicate {
    public final /* synthetic */ Set f$0;

    public /* synthetic */ SipMsg$$ExternalSyntheticLambda28(Set set) {
        this.f$0 = set;
    }

    public final boolean test(Object obj) {
        return this.f$0.contains((String) obj);
    }
}
