package com.sec.internal.constants.ims;

import android.util.Pair;
import java.util.function.Function;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda10 implements Function {
    public final /* synthetic */ Pair f$0;

    public /* synthetic */ SipMsg$$ExternalSyntheticLambda10(Pair pair) {
        this.f$0 = pair;
    }

    public final Object apply(Object obj) {
        return SipMsg.lambda$getViaHostPort$15(this.f$0, (String) obj);
    }
}
