package com.sec.internal.constants.ims.cmstore;

public class ScheduleConstant {
    public static final long POLLING_TIME_OUT = 360000;
    public static final int UPDATE_SUBSCRIPTION_DELAY_TIME = 60000;
}
