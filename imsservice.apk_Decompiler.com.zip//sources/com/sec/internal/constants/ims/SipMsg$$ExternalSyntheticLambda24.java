package com.sec.internal.constants.ims;

import java.util.Map;
import java.util.function.Function;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda24 implements Function {
    public final Object apply(Object obj) {
        return SipMsg.lambda$new$3((Map.Entry) obj);
    }
}
