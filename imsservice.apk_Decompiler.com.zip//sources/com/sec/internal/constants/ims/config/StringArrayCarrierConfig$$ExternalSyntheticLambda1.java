package com.sec.internal.constants.ims.config;

import java.util.function.IntFunction;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class StringArrayCarrierConfig$$ExternalSyntheticLambda1 implements IntFunction {
    public final Object apply(int i) {
        return StringArrayCarrierConfig.lambda$putOverrideConfig$0(i);
    }
}
