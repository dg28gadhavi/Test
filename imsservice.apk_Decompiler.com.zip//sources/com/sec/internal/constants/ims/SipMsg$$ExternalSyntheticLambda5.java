package com.sec.internal.constants.ims;

import android.util.ArraySet;
import java.util.function.BinaryOperator;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda5 implements BinaryOperator {
    public final Object apply(Object obj, Object obj2) {
        return ((ArraySet) obj).addAll((ArraySet) obj2);
    }
}
