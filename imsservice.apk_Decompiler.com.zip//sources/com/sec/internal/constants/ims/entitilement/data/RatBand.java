package com.sec.internal.constants.ims.entitilement.data;

import java.util.ArrayList;

public class RatBand {
    public ArrayList<String> bands;
    public Integer rat;
}
