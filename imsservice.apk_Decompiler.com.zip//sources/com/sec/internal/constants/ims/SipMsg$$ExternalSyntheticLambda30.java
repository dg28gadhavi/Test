package com.sec.internal.constants.ims;

import java.util.Set;
import java.util.function.Consumer;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda30 implements Consumer {
    public final /* synthetic */ Set f$0;

    public /* synthetic */ SipMsg$$ExternalSyntheticLambda30(Set set) {
        this.f$0 = set;
    }

    public final void accept(Object obj) {
        SipMsg.lambda$getTagsForServices$4(this.f$0, (String) obj);
    }
}
