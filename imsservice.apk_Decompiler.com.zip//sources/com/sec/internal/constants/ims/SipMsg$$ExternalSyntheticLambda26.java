package com.sec.internal.constants.ims;

import java.util.function.Function;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda26 implements Function {
    public final Object apply(Object obj) {
        return SipMsg.lambda$getParam$7((String) obj);
    }
}
