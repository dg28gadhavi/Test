package com.sec.internal.constants.ims.entitilement.data;

public class LocAndTcWebSheetData {
    public String clientName;
    public String title;
    public String token;
    public String url;

    public LocAndTcWebSheetData(String str, String str2, String str3, String str4) {
        this.url = str;
        this.token = str2;
        this.title = str3;
        this.clientName = str4;
    }
}
