package com.sec.internal.constants.ims.cmstore.data;

public enum OperationEnum {
    AddFlag,
    RemoveFlag
}
