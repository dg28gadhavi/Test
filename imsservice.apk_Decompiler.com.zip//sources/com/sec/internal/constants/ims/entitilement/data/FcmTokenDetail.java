package com.sec.internal.constants.ims.entitilement.data;

public class FcmTokenDetail {
    public String deviceUid;
    public String protocolToServer;
    public String senderId;
}
