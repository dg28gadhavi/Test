package com.sec.internal.constants.ims;

import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda8 implements Consumer {
    public final /* synthetic */ Set f$0;

    public /* synthetic */ SipMsg$$ExternalSyntheticLambda8(Set set) {
        this.f$0 = set;
    }

    public final void accept(Object obj) {
        this.f$0.addAll((List) obj);
    }
}
