package com.sec.internal.constants.ims;

import java.util.function.Function;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda27 implements Function {
    public final /* synthetic */ String f$0;

    public /* synthetic */ SipMsg$$ExternalSyntheticLambda27(String str) {
        this.f$0 = str;
    }

    public final Object apply(Object obj) {
        return SipMsg.lambda$getFeatureTags$9(this.f$0, (String) obj);
    }
}
