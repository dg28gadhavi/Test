package com.sec.internal.constants.ims;

import java.util.function.Function;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda29 implements Function {
    public final Object apply(Object obj) {
        return SipMsg.lambda$static$0((String) obj);
    }
}
