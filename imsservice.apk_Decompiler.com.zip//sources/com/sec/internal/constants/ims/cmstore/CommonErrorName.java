package com.sec.internal.constants.ims.cmstore;

public class CommonErrorName {
    public static final String DEFAULT_ERROR_TYPE = "default_error_type";
    public static final String RETRY_HEADER = "retry_header";
}
