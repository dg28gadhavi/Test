package com.sec.internal.constants.ims;

import java.util.function.Supplier;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda34 implements Supplier {
    public final /* synthetic */ SipMsg f$0;

    public /* synthetic */ SipMsg$$ExternalSyntheticLambda34(SipMsg sipMsg) {
        this.f$0 = sipMsg;
    }

    public final Object get() {
        return this.f$0.lambda$getExpire$21();
    }
}
