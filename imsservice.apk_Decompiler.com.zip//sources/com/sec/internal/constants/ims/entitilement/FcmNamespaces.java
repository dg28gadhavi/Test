package com.sec.internal.constants.ims.entitilement;

public class FcmNamespaces {
    public static final String CONFIRMATION_URL = "confirmation_url";
    public static final String MANAGE_PUSH_TOKEN_TO_SES = "managePushToken";
    public static final String PUSH_MESSAGE = "push-message";
}
