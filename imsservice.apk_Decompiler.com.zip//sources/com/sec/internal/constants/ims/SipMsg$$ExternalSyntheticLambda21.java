package com.sec.internal.constants.ims;

import java.util.function.Function;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda21 implements Function {
    public final Object apply(Object obj) {
        return ((StringBuilder) obj).toString();
    }
}
