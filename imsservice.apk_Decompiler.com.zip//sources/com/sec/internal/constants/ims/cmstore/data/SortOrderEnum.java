package com.sec.internal.constants.ims.cmstore.data;

public class SortOrderEnum {
    public static final String Attribute = "Descending";
    public static final String Date = "Ascending";
}
