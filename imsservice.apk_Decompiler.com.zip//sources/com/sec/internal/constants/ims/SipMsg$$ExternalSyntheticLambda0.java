package com.sec.internal.constants.ims;

import com.sec.internal.constants.ims.SipMsg;
import java.util.function.Function;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda0 implements Function {
    public final Object apply(Object obj) {
        return ((SipMsg.StartLine) obj).toString();
    }
}
