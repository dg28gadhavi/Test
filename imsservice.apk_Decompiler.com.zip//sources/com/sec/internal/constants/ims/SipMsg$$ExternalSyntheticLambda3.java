package com.sec.internal.constants.ims;

import android.util.ArraySet;
import java.util.function.Supplier;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class SipMsg$$ExternalSyntheticLambda3 implements Supplier {
    public final Object get() {
        return new ArraySet();
    }
}
