package com.sec.internal.constants.ims.cmstore.data;

public class SortTypeEnum {
    public static final String Attribute = "Attribute";
    public static final String Date = "Date";
}
