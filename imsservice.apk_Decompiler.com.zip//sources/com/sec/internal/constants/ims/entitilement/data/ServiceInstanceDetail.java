package com.sec.internal.constants.ims.entitilement.data;

public class ServiceInstanceDetail {
    public long lineId;
    public String serviceFingerPrint;
    public String serviceInstanceId;
    public String serviceInstanceToken;
    public String serviceMsisdn;
    public String serviceName;
    public String serviceTokenExpiryTime;
}
