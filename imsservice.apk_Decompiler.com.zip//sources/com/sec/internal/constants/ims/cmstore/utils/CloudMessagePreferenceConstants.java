package com.sec.internal.constants.ims.cmstore.utils;

public class CloudMessagePreferenceConstants {
    public static final String AMBS_PAUSE_SERVICE = "ambs_pause_service";
    public static final String AMBS_STOP_SERVICE = "ambs_stop_service";
    public static final String LAST_RETRY_TIME = "last retry time";
    public static final String RETRY_TOTAL_COUNTER = "retry_total_counter";
    public static final String VVM_ON_STATUS = "vvm_on_status";
}
