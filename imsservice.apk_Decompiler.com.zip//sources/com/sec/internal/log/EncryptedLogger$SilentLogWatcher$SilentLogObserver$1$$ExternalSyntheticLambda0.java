package com.sec.internal.log;

import com.sec.internal.log.EncryptedLogger;
import java.nio.file.Path;
import java.util.function.BinaryOperator;

/* compiled from: R8$$SyntheticClass */
public final /* synthetic */ class EncryptedLogger$SilentLogWatcher$SilentLogObserver$1$$ExternalSyntheticLambda0 implements BinaryOperator {
    public final Object apply(Object obj, Object obj2) {
        return EncryptedLogger.SilentLogWatcher.SilentLogObserver.AnonymousClass1.lambda$run$0((Path) obj, (Path) obj2);
    }
}
