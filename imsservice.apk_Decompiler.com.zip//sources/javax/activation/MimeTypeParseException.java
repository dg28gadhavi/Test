package javax.activation;

public class MimeTypeParseException extends Exception {
    public MimeTypeParseException(String str) {
        super(str);
    }
}
