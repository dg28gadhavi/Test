package javax.mail;

public interface MessageAware {
    MessageContext getMessageContext();
}
