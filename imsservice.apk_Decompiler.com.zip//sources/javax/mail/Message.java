package javax.mail;

public abstract class Message implements Part {
}
